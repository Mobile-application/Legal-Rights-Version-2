
local composer = require( "composer" )


composer.gotoScene( "FirstScene" , { effect="fade", time=500 })



